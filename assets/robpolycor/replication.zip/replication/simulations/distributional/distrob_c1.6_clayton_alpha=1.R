## assess distributional robustness of polycor and robcat
source("simulations/distributional/vita_funs.R")

## for computation
tm <- Sys.time()
num_cores <- 8L
dir_save <- "simulations/distributional/results"
suffix <- "clayton"

### here we emulate the simulation of correlation between variable pair (2,3) in foldnes2019
rho_true_arr <- c(0.9, 0.3)

## clayton copula found by VITA
copula_ls <- 
  lapply(seq_along(rho_true_arr), function(r){
    param_vita <- vita(cor_target = rho_true_arr[r], type = "clayton")
    copula <- copula::claytonCopula(param = param_vita, dim = 2L)
    return(copula)
  })
names(copula_ls) <- rho_true_arr



## simulation parameters
repetitions <- 1000L
N <- 1000L
num_likert_X <- 5L
num_likert_Y <- 5L
thresX <- c(-Inf, -1.5, -1, -0.5, 1.5, Inf)
thresY <- c(-Inf, 0, 0.5, 1, 1.5, Inf)
c <- 1.6
theta_true <- 
  lapply(seq_along(rho_true_arr), function(r)
  {
    c(rho_true_arr[r], thresX[-c(1,num_likert_X+1)], thresY[-c(1,num_likert_Y+1)])
  })
names(theta_true) <- rho_true_arr


## reproducibility
rng <- RNGkind()
set.seed(489254, "L'Ecuyer")
on.exit(RNGkind(kind = rng[1], normal.kind = rng[2], sample.kind = rng[3]))


## start simulation
RESULTS <- 
  parallel::mclapply(X = seq_len(repetitions), mc.cores = num_cores, FUN = function(reps){
    
    # init
    RESULTS. <- NULL
    datasets <- list()
    
    for(r in seq_along(rho_true_arr))
    {

      ### CLAYTON COPULA AT GIVEN CORRELATION
      xi_clayton <- rgaussmargins(n = N, copula = copula_ls[[r]])
      x_clayton <- as.integer(cut(xi_clayton[,1], thresX))
      y_clayton <- as.integer(cut(xi_clayton[,2], thresY))
      
      ## tabulate data
      tab_clayton <- table(x = x_clayton, y = y_clayton)
      
      # MLE
      mle_obj <- robcat::polycor_mle(x = x_clayton, y = y_clayton, variance = FALSE)
      thetahat_mle <- mle_obj$thetahat
      
      # robust
      rob_obj <- robcat::polycor(x = x_clayton, y = y_clayton, c = c, variance = FALSE)
      thetahat_rob <- rob_obj$thetahat
      
      # collect
      tmp <- cbind(rbind(thetahat_rob, thetahat_mle), 
                   convergence = c(rob_obj$optim$convergence, mle_obj$optim$convergence),
                   rob = c(1, 0), rho_true = rho_true_arr[r])
      rownames(tmp) <- NULL
      RESULTS. <- rbind(RESULTS., tmp)

      datasets[[r]] <- tab_clayton

    } # FOR rho
    names(datasets) <- rho_true_arr
    
    return(list(results = RESULTS., datasets = datasets))
    
  }) # mclapply r



print("Done!")
runtime <- difftime(Sys.time(), tm, tz = "UTC", units = "hours")
print(runtime)

nam <- paste0("/distrob_", suffix, "_num-likert=", num_likert_X, "_rho=", min(rho_true_arr), "-to-", max(rho_true_arr), "_c=", c, "_N=", N, "_repetitions=", repetitions, "_alpha=1.Rdata")
save(RESULTS, theta_true, num_likert_X, num_likert_Y, N, num_cores, runtime, thresX, thresY, c, rho_true_arr, copula_ls,
     file = paste0(dir_save, nam))
