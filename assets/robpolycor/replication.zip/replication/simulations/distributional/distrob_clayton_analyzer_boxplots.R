library("dplyr")
library("ggplot2")
library("copula")

## load simulation results
dir_load <- "simulations/distributional/results"
dir_save <- "simulations/distributional/plots"
suffix <- "clayton"
num_likert_X <- 5
rho_true_arr <- c(0.9, 0.3) 
N <- 1000
repetitions <- 1000
c <- 1.6

## load results
nam <- paste0("/distrob_", suffix, "_num-likert=", num_likert_X, "_rho=", min(rho_true_arr), "-to-", max(rho_true_arr), "_c=", c, "_N=", N, "_repetitions=", repetitions, "_alpha=1.Rdata")
load(paste0(dir_load, nam))


DF <- do.call("rbind", lapply(seq_along(RESULTS), function(i) cbind(RESULTS[[i]]$results, r = 1) ))
DF <- as.data.frame(DF)

cut <- qnorm(0.975) - qnorm(0.025) # cover 95% of probability mass
unconverged <- DF$convergence > 1
DF[unconverged,]
sum(unconverged)
DF <- DF[!unconverged,]

## drop unstable estimates (only 2 + 6 = 8 in total)
instable <- (abs(DF$a1 - DF$a2) > cut | abs(DF$a3 - DF$a4) > cut | abs(DF$b1 - DF$b2) > cut | abs(DF$b3 - DF$b4) > cut)
sum(instable)
DF[instable,]
DF <- DF[!instable,]


## prepare DF
DF$Estimator <- recode(DF$rob,
                       `1` = "Robust",
                       `0` = "MLE")

DF$Cor <- paste0('rho["G"]*" = "*', as.character(DF$rho_true))

DF$Estimator <- factor(DF$Estimator, levels = c("Robust", "MLE"))
DF$Cor <- factor(DF$Cor, levels = paste0('rho["G"]*" = "*', as.character(rho_true_arr)))

DF$rho_bias <- DF$rho - DF$rho_true


## box plot
p <- ggplot(DF, mapping = aes(y = rho_bias, color = Estimator)) +
  theme_bw() + 
  geom_hline(yintercept = 0, linetype = "dashed") + 
  geom_boxplot() +
  facet_grid(cols = vars(Cor), labeller = label_parsed) +
  scale_color_brewer(palette = "Dark2") +
  ylab(expression("Bias: "*widehat(rho)["N"]*" - "*rho["G"])) +
  theme(legend.position = "top", 
        axis.title.x = element_blank(),
        axis.text.x = element_blank(), 
        axis.ticks.x = element_blank()) 
nam <- paste0("/distrob_rho_boxplot_", suffix, "_num-likert=", num_likert_X, "_rho=", min(rho_true_arr), "-to-", max(rho_true_arr), "_c=", c, "_N=", N, "_repetitions=", repetitions, "_alpha=1.pdf")

ggsave(filename = nam, plot = p,
       device = "pdf", path = dir_save, width = 0.5*10, height = 0.5*5)

