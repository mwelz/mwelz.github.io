rm(list = ls()) ; cat("\014")
library("ggplot2")
library("copula")
library("dplyr")
source("simulations/distributional/vita_funs.R")

dir_save <- "simulations/distributional/plots"

cor_target1 <- 0.3
cor_target2 <- 0.9
sigma1 <- matrix(c(1,cor_target1,cor_target1,1),2,2)
sigma2 <- matrix(c(1,cor_target2,cor_target2,1),2,2)
mean <- c(0, 0)

## clayton VITA 
param_vita1 <- vita(cor_target = cor_target1, type = "clayton")
copula1 <- copula::claytonCopula(param = param_vita1, dim = 2L)
mvdc1 <- mvdc(copula = copula1, 
              margins = c("norm", "norm"),
              paramMargins = list(list(mean = 0, sd = 1), 
                                  list(mean = 0, sd = 1)))
param_vita2 <- vita(cor_target = cor_target2, type = "clayton")
copula2 <- copula::claytonCopula(param = param_vita2, dim = 2L)
mvdc2 <- mvdc(copula = copula2, 
              margins = c("norm", "norm"),
              paramMargins = list(list(mean = 0, sd = 1), 
                                  list(mean = 0, sd = 1)))


####### create the data frame
n <- 100
x_seq <- seq(from = -2.6, to = 2.2, length.out = n)
y_seq <- seq(from = -2.6, to = 2.2, length.out = n)
m1 <- matrix(NA_real_, nrow = n^2, ncol = 5)
colnames(m1) <- c("x", "y", "z", "type", "cor")
m4 <- m3 <- m2 <- m1


k <- 1L
for(i in seq_along(x_seq))
{
  for(j in seq_along(y_seq))
  {
    x <- x_seq[i]
    y <- y_seq[j]
    
    # gaussians
    m1[k,] <-
      c(x, y, mvtnorm::dmvnorm(x = c(x, y), mean = mean, sigma = sigma1),
        type = 1, cor = cor_target1)
    m2[k,] <-
      c(x, y, mvtnorm::dmvnorm(x = c(x, y), mean = mean, sigma = sigma2),
        type = 1, cor = cor_target2)
    
    # copulas
    m3[k,] <-
      c(x, y, dMvdc(x = c(x, y), mvdc = mvdc1),
        type = 2, cor = cor_target1)
    m4[k,] <-
      c(x, y, dMvdc(x = c(x, y), mvdc = mvdc2),
        type = 2, cor = cor_target2)
    
    # increment
    k <- k + 1L
  }
}


df <- as.data.frame(rbind(m1, m2, m3, m4))
df$Distribution <- recode(df$type,
                        `1` = "Normal",
                        `2` = "Clayton")

df$Distribution <- factor(df$Distribution, levels = c("Normal", "Clayton"))

df$Cor <- paste0('rho["G"]*" = "*', as.character(df$cor))
df$Cor <- factor(df$Cor, 
                 levels = c("rho[\"G\"]*\" = \"*0.9",
                            "rho[\"G\"]*\" = \"*0.3"))

library("RColorBrewer")
palette_Blues <- colorRampPalette(brewer.pal(9, "Blues"))

p <- ggplot(df, aes(x = x, y = y, z = z)) +
  geom_contour_filled() +
  facet_grid(rows = vars(Cor), cols = vars(Distribution), labeller = label_parsed) +
  scale_fill_manual(values = palette_Blues(10)) +
  scale_y_continuous(expand = c(0,0)) + # cut at edges
  scale_x_continuous(expand = c(0,0)) +
  guides(fill = guide_legend(title = "Density")) +
  theme(legend.position = "right") +
  ylab(expression(eta)) +
  xlab(expression(xi))

ggsave(filename = "distributional_densities_0.9-0.3.pdf", plot = p, 
       device = "pdf", path = dir_save, width = 0.8*10, height = 0.8*6)
