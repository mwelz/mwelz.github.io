## SE of pearson correlation
samplecor <- function(x, y)
{
  r <- cor(x, y, method = "pearson")
  se <- sqrt((1 - r^2) / (length(x) - 2.))
  return(list(thetahat = r, stderr = se))
}

## for computation
tm <- Sys.time()
dir_save <- "simulations/careless/results"
num_cores <- 22 

## simulation parameters
repetitions <- 1000L
N <- 1000L
num_likert_X <- 5L
num_likert_Y <- 5L
thresX <- robcat:::get_thresholds(K = num_likert_X)
thresY <- robcat:::get_thresholds(K = num_likert_Y)
contam_arr <- c(0, 0.01, 0.05, 0.1, 0.15, 0.2) 
c2 <- 1.6

# true distribution (bivariate standard normal, like in any polychoric model)
rho_true <- 0.5
mean_true <- c(0, 0)
covmat_true <- matrix(c(1, rho_true, rho_true, 1),2,2)
theta_true <- c(rho_true, thresX[-c(1,num_likert_X+1)], thresY[-c(1,num_likert_Y+1)])
names(theta_true) <- robcat:::theta_names(num_likert_X, num_likert_Y)


# contaminating distribution
rho_contam <- 0
mean_contam <- c(2,-2)
var_contam <- 0.2
covmat_contam <- matrix(c(var_contam, rho_contam, rho_contam, var_contam), 2, 2)

## print
print(paste0("Starting with ", "num-likert=", num_likert_X, ", rho=", rho_true,
             ", N=", N, ", repetitions=", repetitions))


## reproducibility
rng <- RNGkind()
set.seed(98591456, "L'Ecuyer")
on.exit(RNGkind(kind = rng[1], normal.kind = rng[2], sample.kind = rng[3]))
tm <- Sys.time()

## random initialization of bounds (but doesn't matter because problem is convex)
Kx <- num_likert_X
Ky <- num_likert_Y
thresX_init <- robcat:::init_thresholds(Kx) + runif(Kx-1, -0.45, 0.45) # preserves monotonicity
thresY_init <- robcat:::init_thresholds(Ky) + runif(Ky-1, -0.45, 0.45) # preserves monotonicity
init <- c(0, thresX_init, thresY_init)

## start simulation
RESULTS <- 
  parallel::mclapply(X = seq_len(repetitions), mc.cores = num_cores, FUN = function(reps){
    
    # init
    RESULTS. <- NULL
    
    ## uncontaminated data
    # latent variable
    latent_uncontam <- 
      mvtnorm::rmvnorm(n = N, 
                       mean = mean_true, 
                       sigma = covmat_true)
    
    # responses
    x_uncontam <- robcat:::get_discretization(thresholds = thresX, latent = latent_uncontam[,1])
    y_uncontam <- robcat:::get_discretization(thresholds = thresY, latent = latent_uncontam[,2])
    
    
    for(eps in contam_arr)
    {
      
      ## contaminate
      latent_contam <- latent_uncontam
      y_contam <- y_uncontam
      x_contam <- x_uncontam
      contam_size <- floor(eps * N)
      
      if(eps > 0)
      {
        ## sample contaminated data
        # contaminated latent variable (bad leverage points: negatively correlated)
        latent_contam[seq_len(contam_size),] <- 
          mvtnorm::rmvnorm(n = contam_size, 
                           mean = mean_contam, 
                           sigma = covmat_contam)
        x_contam <- robcat:::get_discretization(thresholds = thresX, latent = latent_contam[,1])
        y_contam <- robcat:::get_discretization(thresholds = thresY, latent = latent_contam[,2])
      } # IF
      
      
      ## estimate and collect results
      mle. <- robcat::polycor_mle(x = x_contam, y = y_contam, init = init)
      rob. <- robcat::polycor(x = x_contam, y = y_contam, init = init, c = c2)
      smp. <- samplecor(x = x_contam, y = y_contam)
      
      mlearr <- c(mle.$thetahat, mle.$stderr)
      robarr <- c(rob.$thetahat, rob.$stderr)
      smparr <- c(smp.$thetahat, rep(NA_real_, num_likert_X-1L),  rep(NA_real_, num_likert_Y-1L), 
                  smp.$stderr, rep(NA_real_, num_likert_X-1L),  rep(NA_real_, num_likert_Y-1L))
      
      tmp <- rbind(mlearr, robarr, smparr) 
      colnames(tmp)[(length(theta_true)+1):ncol(tmp)] <- paste0("stderr ", names(theta_true))
      tmp <- cbind(tmp, eps = eps, method = 1:3)
      
      RESULTS. <- rbind(RESULTS., tmp)
     
    } # eps
    
    return(RESULTS.)
  }) # mclapply r

print("Done!")
runtime <- difftime(Sys.time(), tm, tz = "UTC", units = "hours")
print(runtime)

nam <- paste0("/simresults_num-likert=", num_likert_X, "_rho=", rho_true, "_N=", N, "_repetitions=", repetitions, ".Rdata")
save(RESULTS, theta_true, num_likert_X, num_likert_Y, N, num_cores, contam_arr, c2, mean_true, covmat_true, rho_contam, mean_contam, var_contam, covmat_contam, init, runtime, thresX, thresY, 
     file = paste0(dir_save, nam))

