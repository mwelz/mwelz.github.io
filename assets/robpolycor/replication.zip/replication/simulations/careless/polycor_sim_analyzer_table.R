library("dplyr")

## load simulation results
dir_load <- "simulations/careless/results"
num_likert_X <- 5
rho_true <- 0.5
N <- 1000
c_arr <- c(seq(from = 1.3, to = 2, by = 0.1), Inf)
repetitions <- 1000
nam <- paste0("/simresults_num-likert=", num_likert_X, "_rho=", rho_true, "_N=", N, "_repetitions=", repetitions, ".Rdata")
load(paste0(dir_load, nam))

DF <- do.call("rbind", lapply(seq_along(RESULTS), function(i) cbind(RESULTS[[i]], r = 1) ))
DF <- as.data.frame(DF)
DF <- DF[, c("rho", "stderr rho", "method", "eps")]
DF$method <- recode(DF$method,
                       `2` = "Polycor robust", 
                       `1` = "Polycor ML",
                       `3` = "Sample cor")
DF$method <- factor(DF$method, levels = c("Polycor robust", "Polycor ML", "Sample cor"))

## calculate CIs at 95%
q <- qnorm(0.05/2, lower.tail = FALSE)
DF$cilo <- DF$rho - q * DF$`stderr rho`
DF$ciup <- DF$rho + q * DF$`stderr rho`
DF$coverage <- as.integer(DF$cilo <= rho_true & rho_true <= DF$ciup)
DF$reject <- as.integer(!(DF$cilo <= 0 & 0 <= DF$ciup))
DF$cilength <- 2 * q * DF$`stderr rho`

## print
eps0 <- as.data.frame(DF %>% filter(near(eps, 0)) %>% group_by(method) %>% 
  summarize(rhohat = mean(rho), 
            bias = mean(rho) - rho_true,
            se = sqrt(var(rho)),
            #rr = mean(reject),
            coverage = mean(coverage),
            cilength = mean(cilength)))

eps001 <- as.data.frame(DF %>% filter(near(eps, 0.01)) %>% group_by(method) %>% 
                          summarize(rhohat = mean(rho), 
                                    bias = mean(rho) - rho_true,
                                    se = sqrt(var(rho)),
                                    #rr = mean(reject),
                                    coverage = mean(coverage),
                                    cilength = mean(cilength)))

eps005 <- as.data.frame(DF %>% filter(near(eps, 0.05)) %>% group_by(method) %>% 
                        summarize(rhohat = mean(rho), 
                                  bias = mean(rho) - rho_true,
                                  se = sqrt(var(rho)),
                                  #rr = mean(reject),
                                  coverage = mean(coverage),
                                  cilength = mean(cilength)))

eps01 <- as.data.frame(DF %>% filter(near(eps, 0.1)) %>% group_by(method) %>% 
                        summarize(rhohat = mean(rho), 
                                  bias = mean(rho) - rho_true,
                                  se = sqrt(var(rho)),
                                  #rr = mean(reject),
                                  coverage = mean(coverage),
                                  cilength = mean(cilength)))

eps015 <- as.data.frame(DF %>% filter(near(eps, 0.15)) %>% group_by(method) %>% 
                        summarize(rhohat = mean(rho), 
                                  bias = mean(rho) - rho_true,
                                  se = sqrt(var(rho)),
                                  #rr = mean(reject),
                                  coverage = mean(coverage),
                                  cilength = mean(cilength)))

eps02 <- as.data.frame(DF %>% filter(near(eps, 0.2)) %>% group_by(method) %>% 
                         summarize(rhohat = mean(rho), 
                                   bias = mean(rho) - rho_true,
                                   se = sqrt(var(rho)),
                                   #rr = mean(reject),
                                   coverage = mean(coverage),
                                   cilength = mean(cilength)))

eps0 %>% mutate_if(is.numeric, function(x) round(x, 3))
eps001 %>% mutate_if(is.numeric, function(x) round(x, 3))
eps005 %>% mutate_if(is.numeric, function(x) round(x, 3))
eps01 %>% mutate_if(is.numeric, function(x) round(x, 3))
eps015 %>% mutate_if(is.numeric, function(x) round(x, 3))
eps02 %>% mutate_if(is.numeric, function(x) round(x, 3))
