
# from https://robjhyndman.com/hyndsight/crop-r-figures/index.html
savepdf <- function(file, width=16, height=10)
{
  pdf(file, width=width/2.54, height=height/2.54,
      pointsize=10)
  par(mgp=c(2.2,0.45,0), tcl=-0.4, mar=c(3.3,3.6,1.1,1.1))
}


## simulation parameters
N <- 10000
num_likert_X <- num_likert_Y <- 5
rho_true <- 0.5
thresX <- robcat:::get_thresholds(num_likert_X)
thresY <- robcat:::get_thresholds(num_likert_Y)

mean_true <- c(0, 0)
covmat_true <- matrix(c(1, rho_true, rho_true, 1),2,2)
theta_true <- c(rho_true, thresX[-c(1,num_likert_X+1)], thresY[-c(1,num_likert_Y+1)])
names(theta_true) <- robcat:::theta_names(num_likert_X, num_likert_Y)

### sample data
set.seed(12345)
eps <- 0.15 # contamination
contam_size <- floor(N * eps)

# true distribution (bivariate standard normal, like in any polychoric model)
latent_uncontam <- 
  mvtnorm::rmvnorm(n = N, 
                   mean = mean_true, 
                   sigma = covmat_true)

# contaminating distribution (bad leverage points)
rho_contam <- 0
mean_contam <- c(2,-2)
var_contam <- 0.2
covmat_contam <- matrix(c(var_contam, rho_contam, rho_contam, var_contam), 2, 2)
latent_contam <- 
  mvtnorm::rmvnorm(n = contam_size, 
                   mean = mean_contam, 
                   sigma = covmat_contam)

## model probabilities
probs <- robcat:::model_probabilities(rho = rho_true, 
                             thresX = thresX, thresY = thresY, 
                             Kx = num_likert_X, Ky = num_likert_Y)


# centered support
suppX <- 1:num_likert_X - median(1:num_likert_X)
suppY <- 1:num_likert_Y - median(1:num_likert_Y)
latent <- latent_uncontam
color <- rep("gray", N)
latent[seq_len(contam_size),] <- latent_contam
color[seq_len(contam_size)] <- "orange"

pdf("simulations/plots/simdesign_plot.pdf", width = 0.9*8, height = 0.9*6)
plot(latent[,2], latent[,1], col = scales::alpha(color, 0.5), pch = 16, ylab = expression(xi), xlab = expression(eta))
abline(v = thresY[!is.infinite(thresY)], col = "blue")
abline(h = thresX[!is.infinite(thresX)], col = "blue")
text(-3.6, suppY, 1:num_likert_Y, col = "darkblue")
text(suppX, 3.9, 1:num_likert_X, col = "darkblue")
text(-3.5, 3.9, expression("X" ~ "\u{005C}" ~ "Y"), col = "darkblue")
k <- 1L
names_probs <- rep(NA_character_, num_likert_X * num_likert_Y)
for(x in 1:num_likert_X)
{
  for(y in 1:num_likert_Y)
  {
    pk <- probs[k]
    text(suppY[y], suppX[x], paste0("(", round(pk, 3), ")"), col = "blue")
    names_probs[k] <- paste0("(", x, ",", y, ")")
    k <- k + 1L
  }
}
dev.off()
names(probs) <- names_probs


## calculate rho via MLE and robust alternative
x <- robcat:::get_discretization(latent = latent[,1], thresholds = thresX)
y <- robcat:::get_discretization(latent = latent[,2], thresholds = thresY)
polycor::polychor(x = x, y = y, ML = TRUE) # -0.04928168
robcat::polycor_mle(x = x, y = y) # -0.04983
robcat::polycor(x = x, y = y, c = 1.6) # 0.4532

