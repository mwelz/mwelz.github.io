library("dplyr")
library("ggplot2")
library("RColorBrewer")

## load simulation results
dir_load <- "simulations/careless/results"
dir_save <- "simulations/careless/plots"
num_likert_X <- 5
rho_true <- 0.5
N <- 1000
repetitions <- 1000

## load results and subset them to desired c
nam <- paste0("/simresults_num-likert=", num_likert_X, "_rho=", rho_true, "_N=", N, "_repetitions=", repetitions, ".Rdata")
load(paste0(dir_load, nam))

DF <- do.call("rbind", lapply(seq_along(RESULTS), function(i) cbind(RESULTS[[i]], r = 1) ))
DF <- as.data.frame(DF)

## prepare DF
DF$Estimator <- recode(DF$method,
                       `1` = "Polycor ML",
                       `2` = "Polycor robust", 
                       `3` = "Sample cor")
DF$Estimator <- factor(DF$Estimator, levels = c("Polycor robust", "Polycor ML", "Sample cor"))


DF$rho_bias <- DF$rho - rho_true
DF$Eps <- paste0('epsilon*" = "*', as.character(DF$eps)) # to-be-parsed labels

## MSE of estimated parameters
theta_true_mat <- do.call("rbind", lapply(seq_len(nrow(DF)), function(...) theta_true))
colnames(theta_true_mat) <- colnames(DF)[seq_along(theta_true)]
# squared l2 bias
DF$bias_l2 <- rowSums((DF[,seq_along(theta_true)] - theta_true_mat)^2, na.rm = TRUE) # thresholds aren't estimated in sample cor

## box plot
# rho
p <- ggplot(DF, mapping = aes(y = rho_bias, color = Estimator)) +
  theme_bw() + 
  geom_hline(yintercept = 0, linetype = "dashed") + 
  geom_boxplot() +
  scale_color_brewer(palette = "Dark2") +
  facet_grid(cols = vars(Eps), labeller = label_parsed) +
  xlab(expression("Misspecification fraction "*epsilon)) + 
  ylab(expression("Bias: "*widehat(rho)["N"]*" - "*rho["*"])) +
  theme(legend.position = "top", 
        axis.text.x = element_blank(), 
        axis.ticks.x = element_blank())
nam <- paste0("sim_rho_boxplot_num-likert=", num_likert_X, "_rho=", rho_true, "_c=",c2, "_N=", N, "_repetitions=", repetitions, ".pdf")
ggsave(filename = nam, plot = p,
       device = "pdf", path = dir_save, width = 0.42*16.5 , height = 0.42*6)

# theta
# don't plot sample cor because it's redundant (no thresholds estimated anyway)
DF_short <- DF %>% filter(method != 3)
p <- ggplot(DF_short, mapping = aes(y = bias_l2, color = Estimator)) +
  theme_bw() + 
  geom_hline(yintercept = 0, linetype = "dashed") + 
  geom_boxplot() +
  facet_grid(cols = vars(Eps), labeller = label_parsed) +
  xlab(expression("Misspecification fraction "*epsilon)) + 
  ylab(expression("||"*widehat(theta)["N"]*" - "*theta["*"]*"||"^2)) +
  theme(legend.position = "top", 
        axis.text.x = element_blank(), 
        axis.ticks.x = element_blank())
nam <- paste0("sim_theta_boxplot_num-likert=", num_likert_X, "_rho=", rho_true, "_c=",c2, "_N=", N, "_repetitions=", repetitions, ".pdf")
ggsave(filename = nam, plot = p,
       device = "pdf", path = dir_save, width = 0.6*10, height = 0.6*8)
