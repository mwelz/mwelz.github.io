This folder contains replication files for all numerical results in the paper. The code was primarily written by Max Welz (max.welz<at>uzh.ch) with edits (and lots of gratefully acknowledged guideance) by Andreas Alfons (alfons<at>ese.eur.nl).

Structure:

- `simulations`: simulation studies (Sections 6 and 8)
	-`careless`: Section 6.1
	-`cormat`: Section 6.2
	-`distributional`: Section 8
- `applications`: empirical application in Section 7

All results are computed with our package `robcat`, install via `devtools::install_github("mwelz/robcat")`

NOTE: in the scripts for the robcat package, we used a differemt definition of Pearson residuals where we did NOT normalize by deducting value 1 (as we do in the paper). Consequently, the tuning constant c is location-shifted by value 1. For instance, what is c = 0.6 in the paper means c = 1.6 in the script.

