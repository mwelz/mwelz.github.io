source("simulations/cormat/fa_funs.R")
dir_save <- "simulations/cormat"

n <- 1000L
num_reps <- 1000L
c <- 1.6
contam_arr <- c(0, 0.01, 0.05, 0.1, 0.15, 0.2)
thresholds_type <- "symmetric"
loadings <- matrix(c(0.8, 0.7, 0.6, 0.5, 0.4), ncol = 1)
p <- nrow(loadings)
num_likert <- 5L
num_cores <- 8L

## prep objects
Sigma <- factormodel_cov(loadings = loadings)$Sigma
thresholds <- get_thresholds(num_variables = p, type = thresholds_type, num_likert = num_likert)

## reproducibility
rng <- RNGkind()
set.seed(98591456, "L'Ecuyer")
on.exit(RNGkind(kind = rng[1], normal.kind = rng[2], sample.kind = rng[3]))
tm <- Sys.time()


## start simulation
RESULTS <- 
  parallel::mclapply(X = seq_len(num_reps), mc.cores = num_cores, FUN = function(reps){
  
  # init
  RESULTS. <- NULL
  
  ## uncontaminated data
  latent_uncontam <- factormodel_draw(n = n, loadings = loadings, Sigma = Sigma)
  ordinal_uncontam <- discretize(latent = latent_uncontam, thresholds = thresholds)
  
  for(eps in contam_arr)
  {
    latent_contam <- latent_uncontam
    ordinal_contam <- ordinal_uncontam
    contam_size <- floor(eps * n)
    
    if(eps > 0)
    {
      ## sample contaminated data
      latent_contam[seq_len(contam_size),] <- 
        cbind(ordinal::rgumbel(contam_size, scale = 3,), 
              ordinal::rgumbel(contam_size, scale = 3),
              ordinal::rgumbel(contam_size, scale = 3),
              ordinal::rgumbel(contam_size, scale = 3),
              ordinal::rgumbel(contam_size, scale = 3))
      ordinal_contam <- discretize(latent = latent_contam, thresholds = thresholds)
    } # IF
    
    ## robust estimator
    rob_obj <- robcat::polycormat(data = ordinal_contam, c = c, parallel = FALSE, variance = FALSE)
    cors_rob <- get_unique_cors(rob_obj)
    
    ## MLE
    mle_obj <- robcat::polycormat_mle(data = ordinal_contam, parallel = FALSE, variance = FALSE)
    cors_mle <- get_unique_cors(mle_obj)
    
    ## collect results
    tmp <- cbind(rbind(cors_rob, cors_mle), robust = c(1, 0), eps = eps)
    RESULTS. <- rbind(RESULTS., tmp)
    
  } # FOR eps
  
  return(RESULTS.)
  system(sprintf('echo "%s"', paste0("done with ", reps, " at ", Sys.time(), collapse="")))
  
}) # mclapply r



print("Done!")
runtime <- difftime(Sys.time(), tm, tz = "UTC", units = "hours")
print(runtime)

nam <- paste0("/RESULTS_FG2020_gumbel_thres=", thresholds_type, "_num-likert=", num_likert, 
              "_c=", c, "_n=", n, "_reps=", num_reps, ".Rdata")
save(RESULTS, loadings, n, num_cores, contam_arr, c, runtime, Sigma, thresholds, thresholds_type, p, num_likert, num_reps, 
     file = paste0(dir_save, nam))
