## based on a factor model, calculate population covariance matrices of observed data X (Sigma) and specific factors (Psi)
# 'loadings' is pxk matrix of factor loadings; sometimes denoted by\Lambda
# 'sigma2' is p-vector of variances of X (main diagonal of Sigma)
factormodel_cov <- function(loadings, sigma2 = rep(1, nrow(loadings)))
{
  ## input checks
  stopifnot(nrow(loadings) == length(sigma2) && all(sigma2 > 0) && is.matrix(loadings))
  
  ## communalities
  h2 <- rowSums(loadings^2)
  
  ## covariance matrix of specific factor (= error term)
  psi2 <- sigma2 - h2
  Psi <- diag(psi2)
  
  ## covariance matrix of X 
  Sigma <- loadings %*% t(loadings) + Psi 
  
  ## check for proper behavior
  if(!all(psi2 > 0.0)) stop("Heywood case: some specific factor variances aren't strictly positive") 
  if(!all(eigen(Sigma)$values >= 0.0)) stop("Sigma is not psd") 
  
  return(list(Sigma = Sigma, Psi = Psi, communalities = h2))
}

# draw an n-sized sample from a factor model, follows N_p(mu, Sigma)
factormodel_draw <- function(n, loadings, Sigma, mu = rep(0, ncol(Sigma)))
{
  ## dim
  k <- ncol(loadings)
  p <- nrow(loadings)
  
  ## covariance matrix of specific factors (=error terms)
  Psi <- Sigma - loadings %*% t(loadings) 
  
  ## draw common factor (random variable, so it varies per individual)
  f <- mvtnorm::rmvnorm(n = n, mean = rep(0, k), sigma = diag(k))
  
  ## initialize
  dat <- matrix(NA_real_, n, p)
  for(j in seq_len(p))
  {
    fLambda <- as.vector(f %*% loadings[j,])
    u <- rnorm(n = n, mean = 0, sd = sqrt(Psi[j,j])) # unique/specific factor
    dat[,j] <- fLambda + mu[j] + u 
  }
  return(dat)
}

# latent is nxp, thresholds is (p-1)xp (that is, the thresholds of a given variable are in the columns)
discretize <- function(latent, thresholds)
{
  p <- ncol(thresholds)
  data <- matrix(NA_integer_, nrow(latent), p)
  for(j in seq_len(p))
  {
    thres_inf <- c(-Inf, thresholds[,j], Inf)
    data[,j] <- as.integer(cut(latent[,j], thres_inf))
  }
  return(data)
}


## returns theresholds for each variable (thresholds are constant across variables)
## thresholds of each variable are in the columns of the returned object
get_thresholds <- function(num_variables, type, num_likert = 5L)
{
  stopifnot(num_likert == 5L)
  
  ## probabilities 'pr' are taken from figure 5 in https://doi.org/10.1080/10705511.2019.1673168
  if(type == "symmetric")
  {
    pr <- c(0.1, 0.2, 0.4, 0.2, 0.1)
  } else if(type == "moderate")
  {
    # moderately skewed
    pr <- c(0.04, 0.05, 0.21, 0.46, 0.24)
  } else if(type == "severe")
  {
    # severely skewed
    pr <- c(0.04, 0.06, 0.1, 0.32, 0.48)
  } else stop("unknown type")
  
  thres <- qnorm(cumsum(pr[-num_likert]))
  thres_mat <-  Reduce(f = cbind, x  = rep(list(thres), num_variables), init = NULL)
  return(thres_mat)
}


## return the unique polychoric correlation estimates
get_unique_cors <- function(polycormat_obj)
{
  rhohat <- 
    sapply(seq_along(polycormat_obj$polycor_objects), 
           function(ii) polycormat_obj$polycor_objects[[ii]]$thetahat["rho"]
    )
  names(rhohat) <- names(polycormat_obj$polycor_objects)
  return(rhohat)
}


###### functions for analysis

get_unique_cors_Sigma <- function(Sigma)
{
  unique_pairs <- robcat:::unique_pairs(ncol(Sigma))
  cor_arr <- rep(NA_real_, length(unique_pairs))
  
  for(i in seq_along(unique_pairs))
  {
    pair <- unique_pairs[[i]]
    cor_arr[i] <- Sigma[pair[1L], pair[2L]]
  }
  names(cor_arr) <- names(unique_pairs)
  return(cor_arr)
}


# cor_arr is a named array of unique correlations (without the trivial 1s). The names look like "(i,j)" and indicate the location of the correlation in a correlation matrix. Returns that correlation matrix
get_cormat_from_unique <- function(cor_arr)
{
  num_unique <- length(cor_arr)
  p <- as.integer((1 + sqrt(1 + 4 * 2 * num_unique)) / 2)
  corrmat <- diag(p)
  pair_idx <- names(cor_arr)
  pair_idx <- gsub("\\(|\\)", "", pair_idx)
  
  for(k in seq_len(num_unique))
  {
    pairwise <- cor_arr[k]
    nam <- pair_idx[k]
    i <- as.integer(sub(".*,", "", nam))
    j <- as.integer(sub(",.*", "", nam))
    corrmat[i,j] <- corrmat[j,i] <- pairwise
  }
  return(corrmat)
}

