library("dplyr")
library("ggplot2")
source("simulations/cormat/fa_funs.R")

dir_load <- "simulations/cormat"

thresholds_type <- "symmetric"
num_likert <- 5L
c <- 1.6
n <- 1000L
num_reps <- 1000L

load(paste0(dir_load, "/RESULTS_FG2020_gumbel_thres=", thresholds_type, "_num-likert=", num_likert, 
            "_c=", c, "_n=", n, "_reps=", num_reps, ".Rdata"))

DF0 <- do.call("rbind", lapply(seq_along(RESULTS), function(i) cbind(RESULTS[[i]], r = 1) ))
DF0 <- as.data.frame(DF0)

## prepare DF
DF0$Estimator <- factor(recode(DF0$robust,
                        `0` = "MLE",
                        `1` = "Robust"))

DF0$Eps <- factor(DF0$eps)

# number of unique distinct item pairs
num_pairs <- p * (p - 1) / 2


#### line plot
# TODO: we need to take means!
DF_line <- DF0[,!(colnames(DF0) %in% c("robust", "eps", "r"))]

DF_line <- DF_line %>%
  group_by(Estimator, Eps) %>% summarize_all("mean")

estimates_mat <- DF_line[,2+seq_len(num_pairs)]
true_mat <- Reduce(f = rbind, x  = rep(list(get_unique_cors_Sigma(Sigma)), nrow(estimates_mat)), init = NULL)
bias_mat <- abs(estimates_mat - true_mat) 
DF_line[,2+seq_len(num_pairs)] <- bias_mat
DF_line_long <- reshape::melt(as.data.frame(DF_line), id.vars = c("Estimator", "Eps"), variable_name = "Pair")

DF_line_long$Eps <- as.numeric(as.character(DF_line_long$Eps))
p <- 
  ggplot(DF_line_long, mapping = aes(x = Eps, y = value, color = `Pair`)) +
  theme_bw() +
  geom_line() +
  facet_grid(rows = vars(Estimator)) +
  xlab(expression("Misspecification fraction "*epsilon)) + 
  ylab(expression("Absolute bias "*"|"*widehat(rho)["N"]*" - "*rho["*"]*"|")) +
  theme(legend.position = "right")
nam <- paste0("lineplot_gumbel_thres=", thresholds_type, "_num-likert=", num_likert, 
              "_c=", c, "_n=", n, "_reps=", num_reps, ".pdf")
ggsave(filename = nam, plot = p,
       device = "pdf", path = dir_load, width = 0.6*10, height = 0.6*5)
