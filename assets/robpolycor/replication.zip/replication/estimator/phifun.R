phi <- function(x, c1, c2)
{
  out <- ifelse(c1 <= x & x <= c2, (x+1) * log(x+1), 0.0) +
    ifelse(x < c1, (log(c1+1) + 1.0) * (x+1) - c1 - 1, 0.0) +
    ifelse(x > c2, (log(c2+1) + 1.0) * (x+1) - c2 - 1, 0.0) 
  out[is.nan(out)] <- 0.0 # 0 * log(0) = 0
  out
}



c1 <- -Inf
c2 <- 0.6

## ggplot version
library("ggplot2")
x <- seq(from = 0, to = 7.5, by = 0.001) - 1
y <- phi(x, c1, c2)
df <- data.frame(x = x, y = y, Loss = "Robust")
df <- rbind(df, data.frame(x, y = phi(x = x, c1 = -Inf, c2 = Inf), Loss = "MLE"))
df$Loss <- factor(df$Loss, levels = c("Robust", "MLE"))

p <- 
  ggplot() + 
  theme_bw() +
  geom_line(data = df, mapping = aes(x = x, y = y, color = Loss, linetype = Loss)) + 
  geom_vline(xintercept = c2, linetype = "dashed", color = "darkgreen") +
  theme(legend.position = "top", 
        axis.text = element_text(size = 10), axis.title = element_text(size = 11)) +
  scale_color_manual(values = c("blue", "red")) +
  geom_text(aes(x=c2+0.2, label="c", y=15), colour="darkgreen") + 
  ylab(expression(varphi*"(z)")) + 
  xlab("z")

ggsave(filename = "phifun_oneside_ggplot.pdf", plot = p,
       device = "pdf", path = "estimator", width = 0.28*18, height = 0.28*10)

