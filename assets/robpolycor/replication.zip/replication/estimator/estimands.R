rm(list = ls()) ; cat("\014")

# params
num_likert_X <- num_likert_Y <- 5
rho_true <- 0.5
thresX <- robcat:::get_thresholds(num_likert_X)
thresY <- robcat:::get_thresholds(num_likert_Y)
theta_true <- c(rho_true, thresX[-c(1,num_likert_X+1)], thresY[-c(1,num_likert_Y+1)])
names(theta_true) <- robcat:::theta_names(num_likert_X, num_likert_Y)
covmat_true <- matrix(c(1, rho_true, rho_true, 1), 2, 2)
rho_contam <- 0
mean_contam <- c(2,-2)
var_contam <- 0.2
covmat_contam <- matrix(c(var_contam, rho_contam, rho_contam, var_contam), 2, 2)

eps_arr <- seq(from = 0, to = 0.3, by = 0.02)
c_arr <- c(seq(from = 1, to = 2, by = 0.2), Inf)

DF <- NULL

for(eps in eps_arr)
{
  ## population probabilities
  feps <- robcat:::feps_cpp(thresX = thresX, thresY = thresY, 
                            eps = eps, 
                            covmat_true = covmat_true, covmat_contam = covmat_contam, 
                            mean_true = c(0, 0), mean_contam = mean_contam)
  
  for(c in c_arr)
  {
    ## get estimand
    robcatobj <- robcat:::polycor_fast(f = feps, Kx = num_likert_X, Ky = num_likert_Y, 
                                       c1 = 0, c2 = c, N = 1, init = theta_true)
    tmp <- c(robcatobj$thetahat, eps = eps, c = c)
    DF <- rbind(DF, tmp)
  }
}

save(DF, theta_true, file = paste0("estimator/estimands_data.Rdata"))


library("ggplot2")
DF_rho <- as.data.frame(DF[,c("rho", "eps", "c")])
DF_rho_sub <- subset(DF_rho, eps < 0.35 & c %in% c(1,1.2,1.4,1.6,Inf))
DF_rho_sub$c <- DF_rho_sub$c - 1 #reparametrization
DF_rho_sub$c <- factor(DF_rho_sub$c)
DF_rho_sub$c <- dplyr::recode(DF_rho_sub$c, `Inf` = "infinity (MLE)")


p <- ggplot(DF_rho_sub, mapping = aes(x = eps, y = rho, color = c)) +
  geom_line() +
  theme_bw() +
  geom_hline(yintercept = rho_true, linetype = "dashed") +
  xlab(expression("Misspecification fraction "*epsilon)) + 
  ylab(expression("Estimand "*rho["0"])) +
  theme(legend.position = "top") + 
  guides(colour = guide_legend(nrow = 1))

ggsave("estimands.pdf", device = "pdf", plot = p, path = "estimator", width = 0.75*7, height = 0.75*3.5)
