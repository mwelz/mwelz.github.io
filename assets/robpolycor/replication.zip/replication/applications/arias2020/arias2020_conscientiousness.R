## do analysis for the conscientiousness scale 
load("applications/arias2020/data_preprocessed.Rdata")

c <- 1.6
items <- colnames(responses)
responses_C <- responses[,startsWith(items, "C")] # no NAs in any Big5 items in this dataset (only in Greenleaf)

## undo reverse coding of negatively worded items
negword <- which(endsWith(colnames(responses_C), "N"))
for(i in negword)
{
  res <- responses_C[,i]
  res <- abs(res - 5L - 1L) # 5 answer categories
  responses_C[,i] <- res
}

# indeed weak correlations (based on Pearson correlation); but might be affected by carelessness
cor(responses_C)

## greenleaf between first two items
p <- ncol(responses_C)
mle_mat <- rob_mat <- matrix(NA_real_, p, p)
colnames(rob_mat) <- colnames(mle_mat) <- rownames(rob_mat) <- rownames(mle_mat) <- colnames(responses_C)

for(i in seq_len(p))
{
  x <- responses_C[,i]
  for(j in seq_len(p))
  {
    y <- responses_C[,j]
    if(i == j){
      mle_mat[i,i] <- rob_mat[i,i] <- 1.0
    } else if(i < j){
      # MLE
      mle_mat[i,j] <- mle_mat[j,i] <- polycor::polychor(x, y)
      
      # robust
      rob <- robcat::polycor(x = x, y = y, c = c)
      rob_mat[i,j] <- rob_mat[j,i] <- rob$thetahat[1]
    } else{
      next
    } # IF
  } # FOR
} # FOR


# like in greenleaf, MLE has a tendency tp underestimate
round(abs(rob_mat - mle_mat), 4)

save(responses_C, rob_mat, mle_mat, c, file = paste0("applications/arias2020/arias2020_conscientiousness_c=",c,".Rdata"))
