rm(list = ls()) ; cat("\014")
load("applications/arias2020/data_preprocessed.Rdata")

c <- 1.6
items <- colnames(responses)
responses_E <- responses[,startsWith(items, "E")] # no NAs in any Big5 items in this dataset (only in Greenleaf)

## undo reverse coding of negatively worded items
negword <- which(endsWith(colnames(responses_E), "N"))
for(i in negword)
{
  res <- responses_E[,i]
  res <- abs(res - 5L - 1L) # 5 answer categories
  responses_E[,i] <- res
}

# indeed weak correlations (based on Pearson correlation); but might be affected by carelessness
cor(responses_E)

p <- ncol(responses_E)
mle_mat <- rob_mat <- matrix(NA_real_, p, p)
colnames(rob_mat) <- colnames(mle_mat) <- rownames(rob_mat) <- rownames(mle_mat) <- colnames(responses_E)

for(i in seq_len(p))
{
  x <- responses_E[,i]
  for(j in seq_len(p))
  {
    y <- responses_E[,j]
    if(i == j){
      mle_mat[i,i] <- rob_mat[i,i] <- 1.0
    } else if(i < j){
      # MLE
      mle_mat[i,j] <- mle_mat[j,i] <- polycor::polychor(x, y)
      
      # robust
      rob <- robcat::polycor(x = x, y = y, c = c)
      rob_mat[i,j] <- rob_mat[j,i] <- rob$thetahat[1]
    } else{
      next
    } # IF
  } # FOR
} # FOR

# some noticeable differences, especially for E2_N vs E2_P
round(abs(rob_mat - mle_mat), 4)

save(responses_E, rob_mat, mle_mat, c, file = paste0("applications/arias2020/arias2020_extroversion_c=",c,".Rdata"))
