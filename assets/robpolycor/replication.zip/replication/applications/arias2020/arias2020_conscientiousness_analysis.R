c <- 1.6
load(paste0("applications/arias2020/arias2020_conscientiousness_c=",c,".Rdata"))

# ordering the item positions s.t. opposite items to be adjacent
levels <- rep(NA_character_, 12)
seq_tmp <- seq(from = 1, to = 11, by = 2)
for(k in seq_along(seq_tmp)) {
  i <- seq_tmp[k]
  levels[i] <- paste0("C", k, "_P") 
  levels[i+1] <- paste0("C", k, "_N")
}

# change item ordering accordingly
mle_mat <- mle_mat[levels,levels]
rob_mat <- rob_mat[levels,levels]

## observation 1: MLE consistently underestimated rho w.r.t. robust version
abs(mle_mat) < abs(rob_mat)

## observation 2: sizable differences: on average, about 0.07. Highest is 19.8, but there are other large values
summary((abs(rob_mat) - abs(mle_mat))[lower.tri(rob_mat, diag = FALSE)])
sort((abs(rob_mat - mle_mat))[lower.tri(rob_mat, diag = FALSE)], decreasing = FALSE)


## print matrices
round(mle_mat, 2)
round(rob_mat, 2)



library("ggplot2")
diffmat <- abs(rob_mat) - abs(mle_mat)
df <- reshape::melt(diffmat)
colnames(df) <- c("x", "y", "|Robust| − |MLE|")

# reocode factors for ordering
df$x <- factor(df$x, levels = levels)
df$y <- factor(df$y, levels = levels)

p <- ggplot(df, aes(x = x, y = y, fill = `|Robust| − |MLE|`)) +
  geom_tile() +
  scale_fill_gradient2(low="blue", mid = "white", high="red", midpoint = 0) +
  scale_y_discrete(limits = rev) +
  theme(legend.position = "top", axis.title=element_blank() )
ggplot2::ggsave(paste0("arias2020_conscientiousness-absheatmap_c=", c, ".pdf"), plot = p, device = cairo_pdf, path = "applications/arias2020/plots", width = 0.8*6, height = 0.8*6)
