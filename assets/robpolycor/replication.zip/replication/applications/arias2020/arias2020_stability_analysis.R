library("ggplot2")
c <- 1.6
load(paste0("applications/arias2020/arias2020_stability_c=",c,".Rdata"))

## install latest version of package
# devtools::install_github("mwelz/robcat")

# replace S with N
colnames(responses_S) <- colnames(mle_mat) <- rownames(mle_mat) <- colnames(rob_mat) <- rownames(rob_mat) <- 
  gsub(x = colnames(responses_S), pattern = "S", "N")

## check the pair with huge difference btw robust and MLE (not envious vs envious)
x <- responses_S[,"N4_P"]
y <- responses_S[,"N4_N"] 

mle <- robcat::polycor_mle(x = x, y = y)
mle$thetahat # -0.62
# polycor::polychor(x, y, ML = TRUE, std.err = TRUE) ## sanity check with standard package for MLE
rob <- robcat::polycor(x = x, y = y, c = c)
rob$thetahat # -0.92

#### the dot plot (copy-pasted w/ adaptions from plot method)
resid <- rob[["residuals"]]
freq <- rob[["f"]]
Kx <- rob$inputs$Kx; Ky <- rob$inputs$Ky
cutoff <- 4

df <- as.data.frame(matrix(NA, Kx * Ky, 4L))
colnames(df) <- c("x", "y", "Frequency", "Residual")
k <- 1L
for(x in seq_len(Kx))
{
  for(y in seq_len(Ky))
  {
    df[k,] <- c(x, y, freq[x,y], resid[x,y])
    k <- k + 1L
  }
}

## initialize variables to avoid R CMD issue
x <- y <- Residual <- Frequency <- Outlier <- NULL

## is a cell outlying?
is_outlier <- df$Residual > cutoff

# prepare data frame
Xseq <- rev(seq_len(Kx))
Yseq <- seq_len(Ky)
df$x <- factor(df$x, levels = Xseq)
df$y <- factor(df$y, levels = Yseq)
df$Residual[is_outlier] <- cutoff

# save necessary objects to RData file because R session keeps crashing
save(Xseq, Yseq, df, c, cutoff,
     file = "applications/arias2020/plots/stuff_for_plot_Andreas.RData")

## the idea to use separate scales for outliers is from here:
# https://stackoverflow.com/a/9812648
df$PR <- df$Residual - 1 # reparametrization
p <-
  ggplot() +
  theme_bw() +
  scale_color_gradient2("PR", 
                        low = "blue", 
                        mid = "gray", 
                        high = "red", 
                        midpoint = 0, 
                        transform = "log1p", # log(x+1), to take care of negative PR values 
                        limits = c(0.5, 4)-1, 
                        breaks = c(0.5, 1, 2, 4)-1, 
                        labels = c("-0.5", "0.0", "1.0", "\u2265 3.0")) +
  geom_point(data = df, 
             mapping = aes(x = y, y = x, 
                           color = PR, 
                           size = Frequency)) +
  scale_y_discrete(limits = as.character(Xseq)) + 
  scale_x_discrete(limits = as.character(Yseq)) +
  coord_fixed() +
  guides(size = guide_legend(order = 1, title = "Relative\nFrequency"),
         color  = guide_colorbar(order = 2, title = "Pearson\nResidual"))  +
  xlab("Envious") + ylab("Not Envious") 

ggplot2::ggsave(paste0("arias2020_neuroticism-N4PN_c=", c, "_DPR_Andreas.png"), 
                plot = p, device = "png", 
                path = "applications/arias2020/plots", 
                width = 5, height = 4, units = "in")

# due to the unicode symbol, we need grDevices::cairo_pdf() instead of pdf() 
# to save the plot as pdf, but that requires installing lots of stuff on the 
# system level on my Mac. We should generate the pdf on Linux.
grDevices::cairo_pdf(paste0("applications/arias2020/plots/arias2020_neuroticism-N4PN_c=", c, "_DPR_Andreas.pdf"),  width = 5, height = 4)
print(p)
dev.off()



# spell out PR
# p <-
#   ggplot() +
#   theme_bw() +
#   scale_color_gradient2("Residual", 
#                         low = "blue", 
#                         mid = "gray", 
#                         high = "red", 
#                         midpoint = 1, 
#                         transform = "log2", 
#                         limits = c(0.5, 4), 
#                         breaks = c(0.5, 1, 2, 4), 
#                         labels = c("0.5", "1.0", "2.0", "\u2265 4.0")) +
#   geom_point(data = df, 
#              mapping = aes(x = y, y = x, 
#                            color = Residual, 
#                            size = Frequency)) +
#   scale_y_discrete(limits = as.character(Xseq)) + 
#   scale_x_discrete(limits = as.character(Yseq)) +
#   coord_fixed() +
#   guides(size = guide_legend(order = 1, title = "Relative\nFrequency"),
#          color  = guide_colorbar(order = 2, title = "Pearson\nResidual"))  +
#   xlab("Envious") + ylab("Not Envious") 
# 
# ggplot2::ggsave(paste0("arias2020_neuroticism-N4PN_c=", c, "_DPR_Andreas_spelledout.png"), 
#                 plot = p, device = "png", 
#                 path = "applications/arias2020/plots", 
#                 width = 5, height = 4, units = "in")
# 
# grDevices::cairo_pdf(paste0("applications/arias2020/plots/arias2020_neuroticism-N4PN_c=", c, "_DPR_Andreas_spelledout.pdf"),  width = 5, height = 4)
# print(p)
# dev.off()

round(rob$residuals - 1, 3)
