Replication files for the empirical application in Section 7

The *_analysis.R files contain analyses of robustly estimated polychoric correlation matrices for a given scale.

In particular, arias2020_stability_analysis.R replicates the results for the ``envious"--``not envious" item pair (among others)
