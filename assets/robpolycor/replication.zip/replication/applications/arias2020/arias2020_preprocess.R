dat_raw <- foreign::read.spss(file = "applications/arias2020/data/DATA_SAMPLE_1.sav", to.data.frame = TRUE)
responses_raw <- dat_raw[,4:46]
n <- nrow(responses_raw)
p <- ncol(responses_raw)
levels_old <- levels(responses_raw$E1_P) 
levels_new <- seq_along(levels_old)
K <- 5 # number of response categories (same for all items)

## recode answer categories
responses <- matrix(NA_integer_, n, p)
for(j in seq_len(p))
{
  old <- responses_raw[,j]
  new <- responses[,j]
  for(k in seq_len(K))
  {
    idx <- old == levels(old)[k] # needs to be done in this weird way because of weird hidden characters, check this issue for explanation: https://stackoverflow.com/questions/64656479/identical-strings-from-different-data-files-wont-match-in-r
    new[idx] <- levels_new[k]
  }
  responses[,j] <- new
}


sum(is.na(responses))
sum(is.na(responses_raw)) # yay

responses <- as.data.frame(responses)
colnames(responses) <- colnames(responses_raw)

## NA checks:
na <- sapply(seq_len(p), function(j) mean(is.na(responses[,j])) )
names(na) <- colnames(responses) # NAs only present in the Greenleaf scale


## attention checks
att_tmp <- as.character(dat_raw$AC)
attention <- rep("fail", n)
attention[att_tmp == "0"] <- "pass"


## there are 4 scales used  in this study for a total of 43 items
# 1. three Big-5 scales (extroversion [E: 12 items, 6 of which positive], conscientiousness [C: 12/6], emotional stability [S: 12/6]) for a total of 36 items
# 2. Greenleaf (7 items); doesn't measure anything
# 3. attention check (1 item); instructed item
# also LOT-R scale (6 items), but this one is not present in this dataset
save(responses, dat_raw, attention, file = "applications/arias2020/data_preprocessed.Rdata")

